Thank you for purchasing The Ultimate Weapons Pack!

Weapons and items are organized vertically in the following order (48x24 pixels): 

Grenades/Items, Melee Weapons;
Handguns;
Submachine Guns;
Shotguns;
Assault Rifles;
Single Shot Rifles;
Light Machineguns, Heavy Machineguns;
Heavy Duty Weapons;
Misc..

I hope you enjoy this pack.

For any enquiries feel free to contact me directly at jestanql@hotmail.com