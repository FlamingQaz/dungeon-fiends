## Omniboy Jungle Dungeon Tileset

Free dungeon tileset collaboration based on @0x72 original dungeon tileset published on [itch.io](https://0x72.itch.io/dungeontileset-ii)

### Content

<ul>
    <li>All previous tiles with new color schema for dark jungle ambient</li>
    <li>Custom totem obstacle</li>
    <li>Custom totem face for fountains</li>
    <li>Custom trap with wood sticks</li>
    <li>Custom walls with leaves</li>
    <li>Changed wall markers to look more damaged</li>
    <li>Custom animation for monster looking inside the wall</li>
</ul>